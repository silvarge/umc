
export const healthController = (req, res, next) => {
    res.send("HELLO, I'm Healthy!");
};